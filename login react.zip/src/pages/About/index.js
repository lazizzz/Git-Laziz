import Layout from "../../shared_components/Layout";
function AboutPage() {
  return (
    <Layout>
      <h1>Bu About Sahifa</h1>
    </Layout>
  );
}

export default AboutPage;
