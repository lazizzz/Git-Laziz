function Footer() {
  return (
    <footer className="p-4 mt-12 w-full bg-green-500 text-white flex items-center justify-between">
      Bu bir footer
    </footer>
  );
}

export default Footer;
