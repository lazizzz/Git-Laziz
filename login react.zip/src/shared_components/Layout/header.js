
import Navbars from "../Navbar";

function Header() {
  return (
    <header>
      <Navbars/>
    </header>
  );
}

export default Header;
